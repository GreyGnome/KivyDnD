# This looks like:
# dictionary[drag_group][widget] = true

drag_destinations_dict = {}
draggables_dict = {}
